import { generateValidationMessage } from '../util/generate-validation-message.js';
import { cloneNodesObserver } from '../util/clone-nodes-observer.js';

const validateFormSubmit = function(event) {
  let formElement = event.currentTarget

  for(const element of formElement.elements) {
    updateValidationStateForElement(element)
  }

  // The isFormValid boolean respresents all inputs that can
  // be validated with the Constraint Validation API.
  const isFormValid = formElement.checkValidity();
  // Prevent form submission if any of the validation checks fail.
  if (!isFormValid) {
    event.preventDefault();
  }
  // Set the focus to the first invalid input.
  const firstInvalidInputEl = formElement.querySelector('input:invalid');
  firstInvalidInputEl?.focus();
}

const skipInputValidation = function(element) {
  return !element.hasAttribute(`data-live-validation`)
}

const skipFocusoutValidation = function(element) {
  return !element.hasAttribute(`data-focusout-validation`)
}

const skipValidation = function(element) {
  return element.hasAttribute(`data-skip-validation`)
}

const updateValidationStateForElement = function(element) {
  if(!element.checkValidity){ return }
  const isInputValid = element.checkValidity();
  if (!element.required && element.value === '' && isInputValid) {
    // Clear validation states.
    element.classList.remove('is-invalid');
  } else {
    // Toggle valid/invalid state class hooks.
    element.classList.toggle('is-invalid', !isInputValid);
  }
  // Update the `aria-invalid` state based on the input's validity.
  element.setAttribute('aria-invalid', (!isInputValid).toString());
  renderErrorMessagesForElement(element)
}

const liveInputValidationEvent = function(event) {
  let element = event.target
  if(skipInputValidation(element)){ return }
  if(skipValidation(element)){ return }
  updateValidationStateForElement(event.target)
}

const focusoutValidationEvent = function(event) {
  let element = event.target
  if(skipFocusoutValidation(element)){ return }
  if(skipValidation(element)){ return }
  updateValidationStateForElement(event.target)
}

const renderErrorMessagesForElement = function(element) {
  const errorContainerID = element.getAttribute(`aria-describedby`)
  if(!errorContainerID || errorContainerID == ''){ return }

  const errorContainer = document.getElementById(errorContainerID)

  if(!errorContainer){ return }

  let errorList = errorContainer.querySelector(`:scope > ul`)

  if(element.validity.valid) {
    errorList.replaceChildren(...[])
    return
  }

  let listItem = renderErrorMessageListItem(generateValidationMessage(element))
  errorList.replaceChildren(...[listItem])
}

const renderErrorMessageListItem = function(validationMessage) {
  const errorTemplate = document.getElementById(`error-list-item-template`)
  const clone = errorTemplate.content.cloneNode(true);
  let listItem = clone.querySelector("li");

  listItem.querySelector(`:scope > span:last-child`).textContent = validationMessage
  return listItem
}

const setValidationStateForInitialLoad = function(form) {
  for(const element of form.elements) {
    if(element.hasAttribute(`data-server-side-errors`)) {
      continue; // do not change any elements that have server-side errors
    }
    if(element.value !=="" ){
      updateValidationStateForElement(element)
    }
  }
}

const handleBadRequestResponse = function(event) {
  if(event.detail.status != 400){ return }

  const form = event.detail.element

  const formErrorLists = form.querySelectorAll(`:scope .error ul`);
  [...formErrorLists].forEach(errorList => {
    errorList.replaceChildren(...[])
  })

  const fallbackErrorSection = form.querySelector(`.fallback-error-section`)

  event.detail.response.json().then(errors => {
    for(const error of errors) {
      var errorContainer = document.getElementById(error.container_id)
      if(!errorContainer){ errorContainer = fallbackErrorSection }

      var elementToInvalidate = document.getElementById(error.element_id)
      if(elementToInvalidate){
        elementToInvalidate.classList.toggle('is-invalid', true);
      }

      let errorList = errorContainer.querySelector(`:scope > ul`)

      let listItem = renderErrorMessageListItem(error.message)
      errorList.append(listItem)
    }
  })
}


class PracticalFrameworkErrorHandling extends HTMLElement {
  constructor() {
    super();
  }

  get form(){
    return this.querySelector(":scope > form")
  }

  connectedCallback() {
    if(!this.isConnected){ return }

    this.form.setAttribute('novalidate', '')
    this.form.addEventListener('input', liveInputValidationEvent)
    this.form.addEventListener('focusout', focusoutValidationEvent)
    this.form.addEventListener('submit', validateFormSubmit)
    this.form.addEventListener('ajax:response:error', handleBadRequestResponse)
    setValidationStateForInitialLoad(this.form)
  }
  disconnectedCallback(){}
}

PracticalFrameworkErrorHandling.renderErrorListItem = renderErrorMessageListItem
PracticalFrameworkErrorHandling.cloneErrorLists = cloneNodesObserver

if (!window.customElements.get('practical-framework-error-handling')) {
  window.PracticalFrameworkErrorHandling = PracticalFrameworkErrorHandling;
  window.customElements.define('practical-framework-error-handling', PracticalFrameworkErrorHandling);
}
