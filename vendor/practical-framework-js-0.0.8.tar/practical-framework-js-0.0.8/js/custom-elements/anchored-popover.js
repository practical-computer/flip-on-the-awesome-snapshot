import {computePosition, autoPlacement, shift, arrow, autoUpdate} from '@floating-ui/dom';

const handleToggleEvent = function(event) {
  const target = event.target
  if(event.newState == 'closed' && this.cleanup) {
    this.cleanup()
  } else {
    target.setupAutoUpdate()
  }
}

class AnchoredPopoverElement extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    if(!this.isConnected){ return }
    this.setPosition()

    if(this.parentElement.querySelector(`:scope > :popover-open`) == this){
      this.setupAutoUpdate()
    }

    this.setAttribute('initialized', true)

    this.addEventListener('toggle', handleToggleEvent)
  }

  setupAutoUpdate() {
    const updatePosition = this.setPosition.bind(this)
    this.cleanup = autoUpdate(
      this.anchor,
      this,
      updatePosition
    )
  }

  setPosition() {
    const element = this
    const arrowElement = this.arrow

    var autoplacementOptions = {}

    if(this.allowedPlacements){
      autoplacementOptions.allowedPlacements = this.allowedPlacements
    }

    var middleware = [autoPlacement(autoplacementOptions), shift()]


    if(arrowElement) {
      middleware.push(arrow({element: arrowElement}))
    }

    const options = {
      middleware: middleware
    }
    computePosition(this.anchor, element, options).then(({x, y, middlewareData}) => {
      element.style.marginLeft = `${x}px`
      element.style.marginTop = `${y}px`

      if( middlewareData.arrow && arrowElement) {
        const {x: arrowX, y: arrowY} = middlewareData.arrow

        arrowElement.style.left = ''
        arrowElement.style.top = ''
        arrowElement.style.right = ''
        arrowElement.style.bottom = ''

        if(arrowX != null){
          arrowElement.style.left = `${arrowX}px`
        }

        if(arrowY != null){
          arrowElement.style.top = `${arrowY}px`
        }
      }
    })
  }

  get anchor() {
    if(this.isAutoAnchorTarget){
      return document.querySelector(`[popovertarget="${this.id}"]`)
    } else {
      return document.querySelector(this.anchorTarget)
    }
  }

  get arrow() {
    return this.querySelector(`[data-arrow]`)
  }

  get isAutoAnchorTarget() {
    return !this.hasAttribute(`anchored`)
  }

  get anchorTarget() {
    return this.getAttribute(`anchored`)
  }

  get allowedPlacements(){
    if(!this.hasAttribute(`allowed-placements`)){return null}
    return this.getAttribute(`allowed-placements`).split(" ").map(x => x.trim())
  }

  disconnectedCallback(){}
}

if (!window.customElements.get('anchored-popover')) {
  window.AnchoredPopoverElement = AnchoredPopoverElement;
  window.customElements.define('anchored-popover', AnchoredPopoverElement);
}
