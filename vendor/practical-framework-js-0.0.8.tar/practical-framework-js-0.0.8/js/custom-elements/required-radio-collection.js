const atLeastValueOfOneFieldNameSelected = function(fieldset, fieldName) {
  const formData = new FormData(fieldset.form)
  return formData.getAll(fieldName).length > 1
}

const validateFieldset = function(fieldset, fieldName, validationFunction, errorsElement, validationMessage) {
  const isValid = validationFunction(fieldset, fieldName)

  let errorList = errorsElement.querySelector(`:scope > ul`)

  if(isValid){
    errorList.replaceChildren(...[])
  } else {
    errorList.replaceChildren(...[PracticalFrameworkErrorHandling.renderErrorListItem(validationMessage)])
  }

  // Update the `aria-invalid` state based on the input's validity.
  fieldset.setAttribute('aria-invalid', (!isValid).toString());

  return isValid
}

const checkValidationChangeEvent = function(event){
  if(event.currentTarget == event.target){ return }
  const element = event.currentTarget
  return validateFieldset(element.fieldset,
                          element.fieldName,
                          element.validationFunction,
                          element.errorsElement,
                          element.validationMessage
                        )
}

const checkValidationFocusOutEvent = function(event){
  if(event.currentTarget.contains(event.relatedTarget)){ return }
  const element = event.currentTarget
  return validateFieldset(element.fieldset,
                          element.fieldName,
                          element.validationFunction,
                          element.errorsElement,
                          element.validationMessage
                        )
}

class RequiredRadioCollection extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    if(!this.isConnected){ return }
    this.addEventListeners()

    PracticalFrameworkErrorHandling.cloneErrorLists(
      this.errorsElement.querySelector(`:scope > ul`),
      this.errorsElementARIA.querySelector(`:scope > ul`)
    )
  }

  addEventListeners(){
    this.addEventListener(`change`, checkValidationChangeEvent)
    this.addEventListener(`focusout`, checkValidationFocusOutEvent)

    const element = this
    const checkValidationOnSubmitEvent = function(event) {
      const isValid = validateFieldset(element.fieldset,
                                       element.fieldName,
                                       element.validationFunction,
                                       element.errorsElement,
                                       element.validationMessage
                                      )
      if(!isValid) {
        event.preventDefault()
        element.fieldset.querySelector(`input:first-child`).focus()
      }
    }

    this.form.addEventListener(`submit`, checkValidationOnSubmitEvent)
  }

  validateExistingData() {
    const formData = new FormData(this.form)

    if(formData.getAll(this.fieldset) > 1) {
      return validateFieldset(this.fieldset,
                              this.fieldName,
                              this.validationFunction,
                              this.errorsElement,
                              this.validationMessage
                            )
    }
  }

  validationFunction(fieldset, fieldName) {
    return atLeastValueOfOneFieldNameSelected(fieldset, fieldName)
  }

  disconnectedCallback(){}

  get form() {
    return this.fieldset.form
  }

  get fieldset() {
    return document.getElementById(this.getAttribute(`fieldset`))
  }

  get fieldName() {
    return this.getAttribute(`field-name`)
  }

  get errorsElement(){
    return document.getElementById(this.getAttribute(`errors-element`))
  }

  get errorsElementARIA(){
    return document.getElementById(this.getAttribute(`errors-element-aria`))
  }

  get validationMessage(){
    if(this.hasAttribute(`validation-message`)) {
      return this.getAttribute(`validation-message`)
    } else {
      return `Please select an option.`
    }
  }
}

if (!window.customElements.get('required-radio-collection')) {
  window.RequiredRadioCollection = RequiredRadioCollection;
  window.customElements.define('required-radio-collection', RequiredRadioCollection);
}