export async function removeFallbackErrorsOnResetEvent(event) {
  const target = event.target
  target.querySelectorAll(`.fallback-error-section li`).forEach(x => { x.remove() })
}