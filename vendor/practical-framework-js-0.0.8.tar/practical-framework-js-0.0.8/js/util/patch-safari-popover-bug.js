// https://github.com/practical-computer/dispatcher/commit/f9ed8d10ba0900edbcac2990eb56ace359d11a34

function safariPopoverBugPatch(event) {
  const patchCutoff = new Date(2024, 11, 1)
  const now = new Date()
  if(now > patchCutoff) { return }

  let target = event.target.closest(`button:not(:disabled)`)
  if(!target){ return }
  if(!target.hasAttribute(`popovertarget`)){ return }
  if(!target.closest(`form`)){ return }

  let popover = document.getElementById(target.getAttribute(`popovertarget`))
  popover.togglePopover()
}

document.addEventListener(`click`, safariPopoverBugPatch)